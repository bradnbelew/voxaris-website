// src/components/dashboard/CampaignOverview.tsx

import React from 'react';
import {
  TrendingUp,
  TrendingDown,
  Users,
  Calendar,
  DollarSign,
  MessageSquare,
  CheckCircle,
  Target,
} from 'lucide-react';
import { CampaignMetrics } from '../../types/dashboard.types';

interface MetricCardProps {
  title: string;
  value: string | number;
  change?: number;
  changeLabel?: string;
  icon: React.ReactNode;
  color: 'blue' | 'green' | 'purple' | 'orange' | 'red' | 'indigo';
}

const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  change,
  changeLabel,
  icon,
  color,
}) => {
  const colorClasses = {
    blue: 'bg-blue-50 text-blue-600',
    green: 'bg-green-50 text-green-600',
    purple: 'bg-purple-50 text-purple-600',
    orange: 'bg-orange-50 text-orange-600',
    red: 'bg-red-50 text-red-600',
    indigo: 'bg-indigo-50 text-indigo-600',
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border p-4 sm:p-6 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between">
        <div className={`p-2 sm:p-3 rounded-lg ${colorClasses[color]}`}>
          {icon}
        </div>
        {change !== undefined && (
          <div
            className={`flex items-center gap-1 text-xs sm:text-sm ${
              change >= 0 ? 'text-green-600' : 'text-red-600'
            }`}
          >
            {change >= 0 ? (
              <TrendingUp size={14} />
            ) : (
              <TrendingDown size={14} />
            )}
            <span>{Math.abs(change)}%</span>
          </div>
        )}
      </div>
      <div className="mt-3 sm:mt-4">
        <p className="text-xs sm:text-sm text-gray-500">{title}</p>
        <p className="text-xl sm:text-2xl font-bold text-gray-900 mt-1">
          {value}
        </p>
        {changeLabel && (
          <p className="text-xs text-gray-400 mt-1">{changeLabel}</p>
        )}
      </div>
    </div>
  );
};

interface CampaignOverviewProps {
  metrics: CampaignMetrics;
}

const CampaignOverview: React.FC<CampaignOverviewProps> = ({ metrics }) => {
  const calculateChange = (current: number, previous?: number) => {
    if (!previous || previous === 0) return undefined;
    return Math.round(((current - previous) / previous) * 100);
  };

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
      <MetricCard
        title="QR Scans"
        value={metrics.qrScans.toLocaleString()}
        change={calculateChange(
          metrics.scanRate,
          metrics.previousPeriod?.scanRate
        )}
        changeLabel={`${metrics.scanRate.toFixed(1)}% scan rate`}
        icon={<Users size={20} />}
        color="blue"
      />

      <MetricCard
        title="AI Conversations"
        value={metrics.conversations.toLocaleString()}
        changeLabel={`${metrics.conversationRate.toFixed(1)}% engaged`}
        icon={<MessageSquare size={20} />}
        color="purple"
      />

      <MetricCard
        title="Appointments"
        value={metrics.appointments.toLocaleString()}
        change={calculateChange(
          metrics.bookingRate,
          metrics.previousPeriod?.bookingRate
        )}
        changeLabel={`${metrics.bookingRate.toFixed(1)}% booking rate`}
        icon={<Calendar size={20} />}
        color="indigo"
      />

      <MetricCard
        title="Shows"
        value={metrics.shows.toLocaleString()}
        changeLabel={`${metrics.showRate.toFixed(1)}% show rate`}
        icon={<Target size={20} />}
        color="orange"
      />

      <MetricCard
        title="Deals Closed"
        value={metrics.deals.toLocaleString()}
        change={calculateChange(
          metrics.closeRate,
          metrics.previousPeriod?.closeRate
        )}
        changeLabel={`${metrics.closeRate.toFixed(1)}% close rate`}
        icon={<CheckCircle size={20} />}
        color="green"
      />

      <MetricCard
        title="Total Revenue"
        value={`$${(metrics.totalRevenue / 1000).toFixed(0)}k`}
        change={calculateChange(
          metrics.totalRevenue,
          metrics.previousPeriod?.revenue
        )}
        changeLabel={`Avg: $${metrics.avgDealValue.toLocaleString()}`}
        icon={<DollarSign size={20} />}
        color="green"
      />
    </div>
  );
};

export default CampaignOverview;


// src/components/dashboard/LoadingSpinner.tsx

export const LoadingSpinner: React.FC<{ size?: 'sm' | 'md' | 'lg' }> = ({
  size = 'md',
}) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-8 h-8',
    lg: 'w-12 h-12',
  };

  return (
    <div className="flex items-center justify-center">
      <div
        className={`${sizeClasses[size]} animate-spin rounded-full border-2 border-gray-300 border-t-blue-600`}
      />
    </div>
  );
};

export default LoadingSpinner;


// src/components/dashboard/ErrorState.tsx

interface ErrorStateProps {
  error: Error;
  onRetry?: () => void;
}

export const ErrorState: React.FC<ErrorStateProps> = ({ error, onRetry }) => {
  return (
    <div className="min-h-[400px] flex flex-col items-center justify-center p-8">
      <div className="text-red-500 mb-4">
        <svg
          className="w-16 h-16"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
          />
        </svg>
      </div>
      <h3 className="text-lg font-semibold text-gray-900 mb-2">
        Something went wrong
      </h3>
      <p className="text-gray-500 text-center mb-4 max-w-md">
        {error.message || 'An unexpected error occurred while loading the dashboard.'}
      </p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Try Again
        </button>
      )}
    </div>
  );
};

export default ErrorState;


// src/components/dashboard/DateRangePicker.tsx

import { useState, useRef, useEffect } from 'react';
import { format, subDays, startOfMonth, endOfMonth, subMonths } from 'date-fns';
import { Calendar as CalendarIcon, ChevronDown } from 'lucide-react';
import { DateRange } from '../../types/dashboard.types';

interface DateRangePickerProps {
  value: DateRange;
  onChange: (range: DateRange) => void;
}

export const DateRangePicker: React.FC<DateRangePickerProps> = ({
  value,
  onChange,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const presets = [
    { label: 'Last 7 days', getValue: () => ({ start: subDays(new Date(), 7), end: new Date() }) },
    { label: 'Last 30 days', getValue: () => ({ start: subDays(new Date(), 30), end: new Date() }) },
    { label: 'This month', getValue: () => ({ start: startOfMonth(new Date()), end: new Date() }) },
    { label: 'Last month', getValue: () => ({ 
      start: startOfMonth(subMonths(new Date(), 1)), 
      end: endOfMonth(subMonths(new Date(), 1)) 
    }) },
    { label: 'Last 90 days', getValue: () => ({ start: subDays(new Date(), 90), end: new Date() }) },
  ];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handlePresetClick = (preset: typeof presets[0]) => {
    onChange(preset.getValue());
    setIsOpen(false);
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 border rounded-lg bg-white hover:bg-gray-50 transition-colors text-sm"
      >
        <CalendarIcon size={16} className="text-gray-500" />
        <span className="text-gray-700">
          {format(value.start, 'MMM d')} - {format(value.end, 'MMM d, yyyy')}
        </span>
        <ChevronDown size={16} className="text-gray-400" />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border z-20">
          <div className="py-1">
            {presets.map((preset) => (
              <button
                key={preset.label}
                onClick={() => handlePresetClick(preset)}
                className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-100 transition-colors"
              >
                {preset.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default DateRangePicker;
