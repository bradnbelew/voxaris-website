// src/components/dashboard/AIPerformanceMetrics.tsx

import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend,
} from 'recharts';
import { AIMetrics } from '../../types/dashboard.types';
import { MessageSquare, Clock, TrendingUp, Smile } from 'lucide-react';

interface AIPerformanceMetricsProps {
  data: AIMetrics;
}

const AIPerformanceMetrics: React.FC<AIPerformanceMetricsProps> = ({ data }) => {
  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

  const sentimentColor = (score: number) => {
    if (score >= 70) return 'text-green-600';
    if (score >= 40) return 'text-yellow-600';
    return 'text-red-600';
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {/* Top Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 bg-blue-50 rounded-lg">
              <MessageSquare className="w-5 h-5 text-blue-600" />
            </div>
            <p className="text-sm text-gray-500">Total Conversations</p>
          </div>
          <p className="text-3xl font-bold text-gray-900">
            {data.totalConversations.toLocaleString()}
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 bg-purple-50 rounded-lg">
              <Clock className="w-5 h-5 text-purple-600" />
            </div>
            <p className="text-sm text-gray-500">Avg. Duration</p>
          </div>
          <p className="text-3xl font-bold text-gray-900">
            {formatDuration(data.avgDuration)}
          </p>
          <p className="text-xs text-gray-400 mt-1">minutes</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 bg-green-50 rounded-lg">
              <Smile className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-sm text-gray-500">Avg. Sentiment</p>
          </div>
          <p className={`text-3xl font-bold ${sentimentColor(data.avgSentiment)}`}>
            {data.avgSentiment}%
          </p>
          <p className="text-xs text-gray-400 mt-1">positive</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 bg-indigo-50 rounded-lg">
              <TrendingUp className="w-5 h-5 text-indigo-600" />
            </div>
            <p className="text-sm text-gray-500">AI Booking Rate</p>
          </div>
          <p className="text-3xl font-bold text-green-600">
            {data.bookingRate}%
          </p>
          <p className="text-xs text-gray-400 mt-1">conversations → appointments</p>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Daily Trend */}
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Conversation Trend
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data.dailyTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis
                  dataKey="date"
                  tick={{ fontSize: 12 }}
                  tickFormatter={(value) => {
                    const date = new Date(value);
                    return `${date.getMonth() + 1}/${date.getDate()}`;
                  }}
                />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="conversations"
                  stroke="#3B82F6"
                  strokeWidth={2}
                  name="Conversations"
                  dot={false}
                />
                <Line
                  type="monotone"
                  dataKey="bookings"
                  stroke="#10B981"
                  strokeWidth={2}
                  name="Bookings"
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Customer Intent Distribution */}
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Customer Intent
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data.intentDistribution}
                  dataKey="count"
                  nameKey="intent"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  label={({ intent, percent }) =>
                    `${intent}: ${(percent * 100).toFixed(0)}%`
                  }
                  labelLine={false}
                >
                  {data.intentDistribution.map((_, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={COLORS[index % COLORS.length]}
                    />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value: number) => [
                    `${value} conversations`,
                    'Count',
                  ]}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          
          {/* Legend */}
          <div className="mt-4 flex flex-wrap justify-center gap-4">
            {data.intentDistribution.map((item, index) => (
              <div key={item.intent} className="flex items-center gap-2">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: COLORS[index % COLORS.length] }}
                />
                <span className="text-sm text-gray-600">{item.intent}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Objections & Channel Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Objections */}
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Top Objections
          </h3>
          <div className="space-y-4">
            {data.topObjections.map((obj, index) => (
              <div key={index}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-700 truncate pr-2" title={obj.objection}>
                    {obj.objection}
                  </span>
                  <span className="text-gray-500 whitespace-nowrap">
                    {obj.count} ({obj.percentage}%)
                  </span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2">
                  <div
                    className="h-2 rounded-full transition-all duration-500"
                    style={{
                      width: `${obj.percentage}%`,
                      backgroundColor: COLORS[index % COLORS.length],
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
          
          {data.topObjections.length === 0 && (
            <p className="text-center text-gray-500 py-8">
              No objection data available
            </p>
          )}
        </div>

        {/* Channel Performance */}
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Channel Performance
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.channelPerformance}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="channel" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                  }}
                />
                <Bar
                  dataKey="bookingRate"
                  fill="#3B82F6"
                  name="Booking Rate (%)"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Channel Stats */}
          <div className="mt-4 grid grid-cols-3 gap-4 text-center">
            {data.channelPerformance.map((channel) => (
              <div
                key={channel.channel}
                className="p-2 bg-gray-50 rounded-lg"
              >
                <p className="text-xs text-gray-500 truncate">{channel.channel}</p>
                <p className="text-sm font-semibold">
                  {channel.conversations} calls
                </p>
                <p className="text-xs text-green-600">
                  {channel.bookingRate}% booking
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIPerformanceMetrics;
