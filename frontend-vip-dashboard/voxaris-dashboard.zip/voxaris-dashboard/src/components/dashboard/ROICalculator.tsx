// src/components/dashboard/ROICalculator.tsx

import React, { useState, useMemo } from 'react';
import { DollarSign, TrendingUp, Calculator, PieChart } from 'lucide-react';
import { ROIData } from '../../types/dashboard.types';

interface ROICalculatorProps {
  data: ROIData;
}

const ROICalculator: React.FC<ROICalculatorProps> = ({ data }) => {
  const [customMailerCost, setCustomMailerCost] = useState(data.campaignCosts.mailerCost);
  const [customAiCost, setCustomAiCost] = useState(data.campaignCosts.aiMinutesCost);

  const metrics = useMemo(() => {
    const totalCost = customMailerCost + customAiCost + data.campaignCosts.platformCost;
    const { totalLeads, appointments, shows, deals, revenue } = data.results;

    return {
      totalCost,
      costPerLead: totalLeads > 0 ? totalCost / totalLeads : 0,
      costPerAppointment: appointments > 0 ? totalCost / appointments : 0,
      costPerShow: shows > 0 ? totalCost / shows : 0,
      costPerDeal: deals > 0 ? totalCost / deals : 0,
      grossProfit: revenue - totalCost,
      roi: totalCost > 0 ? ((revenue - totalCost) / totalCost) * 100 : 0,
      revenuePerLead: totalLeads > 0 ? revenue / totalLeads : 0,
      revenuePerDeal: deals > 0 ? revenue / deals : 0,
    };
  }, [customMailerCost, customAiCost, data]);

  return (
    <div className="space-y-6">
      {/* Cost Inputs */}
      <div className="bg-white rounded-xl shadow-sm border p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <Calculator size={20} className="text-gray-600" />
          Campaign Costs
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Mailer & Printing Costs
            </label>
            <div className="relative">
              <DollarSign
                className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                size={16}
              />
              <input
                type="number"
                value={customMailerCost}
                onChange={(e) => setCustomMailerCost(Number(e.target.value))}
                className="w-full pl-8 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              AI Minutes Cost
            </label>
            <div className="relative">
              <DollarSign
                className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                size={16}
              />
              <input
                type="number"
                value={customAiCost}
                onChange={(e) => setCustomAiCost(Number(e.target.value))}
                className="w-full pl-8 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Platform Cost (Fixed)
            </label>
            <div className="relative">
              <DollarSign
                className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                size={16}
              />
              <input
                type="number"
                value={data.campaignCosts.platformCost}
                disabled
                className="w-full pl-8 pr-4 py-2 border rounded-lg bg-gray-50 text-gray-500 cursor-not-allowed"
              />
            </div>
          </div>
        </div>

        <div className="mt-4 p-4 bg-gray-50 rounded-lg">
          <div className="flex justify-between items-center">
            <span className="font-medium text-gray-700">Total Campaign Cost</span>
            <span className="text-2xl font-bold text-gray-900">
              ${metrics.totalCost.toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      {/* Results Summary */}
      <div className="bg-white rounded-xl shadow-sm border p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <PieChart size={20} className="text-gray-600" />
          Campaign Results
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <p className="text-sm text-gray-500">Leads</p>
            <p className="text-2xl font-bold text-blue-600">
              {data.results.totalLeads.toLocaleString()}
            </p>
          </div>
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <p className="text-sm text-gray-500">Appointments</p>
            <p className="text-2xl font-bold text-purple-600">
              {data.results.appointments.toLocaleString()}
            </p>
          </div>
          <div className="text-center p-4 bg-orange-50 rounded-lg">
            <p className="text-sm text-gray-500">Shows</p>
            <p className="text-2xl font-bold text-orange-600">
              {data.results.shows.toLocaleString()}
            </p>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <p className="text-sm text-gray-500">Deals</p>
            <p className="text-2xl font-bold text-green-600">
              {data.results.deals.toLocaleString()}
            </p>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <p className="text-sm text-gray-500">Revenue</p>
            <p className="text-2xl font-bold text-green-600">
              ${(data.results.revenue / 1000).toFixed(0)}k
            </p>
          </div>
        </div>
      </div>

      {/* ROI Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Cost Per Metrics */}
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Cost Analysis
          </h3>

          <div className="space-y-4">
            <div className="flex justify-between items-center py-3 border-b">
              <span className="text-gray-600">Cost per Lead</span>
              <span className="font-semibold text-lg">
                ${metrics.costPerLead.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between items-center py-3 border-b">
              <span className="text-gray-600">Cost per Appointment</span>
              <span className="font-semibold text-lg">
                ${metrics.costPerAppointment.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between items-center py-3 border-b">
              <span className="text-gray-600">Cost per Show</span>
              <span className="font-semibold text-lg">
                ${metrics.costPerShow.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between items-center py-3">
              <span className="text-gray-600 font-medium">Cost per Deal</span>
              <span className="font-bold text-xl text-blue-600">
                ${metrics.costPerDeal.toFixed(2)}
              </span>
            </div>
          </div>
        </div>

        {/* ROI Summary */}
        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl shadow-sm p-6 text-white">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <TrendingUp size={20} />
            Return on Investment
          </h3>

          <div className="space-y-6">
            <div>
              <p className="text-green-100 text-sm">Total Revenue</p>
              <p className="text-3xl font-bold">
                ${data.results.revenue.toLocaleString()}
              </p>
            </div>

            <div>
              <p className="text-green-100 text-sm">Gross Profit</p>
              <p className={`text-3xl font-bold ${metrics.grossProfit < 0 ? 'text-red-200' : ''}`}>
                ${metrics.grossProfit.toLocaleString()}
              </p>
            </div>

            <div className="pt-4 border-t border-green-400">
              <p className="text-green-100 text-sm">Campaign ROI</p>
              <p className={`text-5xl font-bold ${metrics.roi < 0 ? 'text-red-200' : ''}`}>
                {metrics.roi.toFixed(0)}%
              </p>
            </div>

            <div className="text-sm text-green-100 bg-green-600/50 rounded-lg p-3">
              {metrics.roi > 0 ? (
                <>
                  For every <strong>$1</strong> spent, you generated{' '}
                  <strong>${(metrics.roi / 100 + 1).toFixed(2)}</strong> in revenue
                </>
              ) : (
                <>
                  Campaign is currently operating at a loss. Consider optimizing
                  conversion rates or reducing costs.
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Revenue Breakdown */}
      <div className="bg-white rounded-xl shadow-sm border p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Revenue Breakdown
        </h3>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 bg-gray-50 rounded-lg text-center">
            <p className="text-sm text-gray-500">Revenue per Lead</p>
            <p className="text-xl font-bold text-gray-900">
              ${metrics.revenuePerLead.toFixed(2)}
            </p>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg text-center">
            <p className="text-sm text-gray-500">Revenue per Deal</p>
            <p className="text-xl font-bold text-gray-900">
              ${metrics.revenuePerDeal.toLocaleString()}
            </p>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg text-center">
            <p className="text-sm text-gray-500">Lead → Deal Rate</p>
            <p className="text-xl font-bold text-gray-900">
              {data.results.totalLeads > 0
                ? ((data.results.deals / data.results.totalLeads) * 100).toFixed(1)
                : 0}%
            </p>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg text-center">
            <p className="text-sm text-gray-500">Profit Margin</p>
            <p className={`text-xl font-bold ${metrics.grossProfit > 0 ? 'text-green-600' : 'text-red-600'}`}>
              {data.results.revenue > 0
                ? ((metrics.grossProfit / data.results.revenue) * 100).toFixed(1)
                : 0}%
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ROICalculator;


// src/components/dashboard/LeadQualityChart.tsx

import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { LeadQualityData } from '../../types/dashboard.types';

interface LeadQualityChartProps {
  data: LeadQualityData;
}

const LeadQualityChart: React.FC<LeadQualityChartProps> = ({ data }) => {
  const chartData = [
    { name: 'Hot', value: data.hot, color: '#EF4444' },
    { name: 'Warm', value: data.warm, color: '#F59E0B' },
    { name: 'Cool', value: data.cool, color: '#3B82F6' },
    { name: 'Cold', value: data.cold, color: '#9CA3AF' },
  ];

  const total = data.hot + data.warm + data.cool + data.cold;

  return (
    <div className="bg-white rounded-xl shadow-sm border p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Lead Quality</h3>
      
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={chartData}
              dataKey="value"
              nameKey="name"
              cx="50%"
              cy="50%"
              innerRadius={50}
              outerRadius={80}
              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
            >
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip formatter={(value: number) => [`${value} leads`, '']} />
          </PieChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 grid grid-cols-4 gap-2">
        {chartData.map((item) => (
          <div key={item.name} className="text-center">
            <div
              className="w-3 h-3 rounded-full mx-auto mb-1"
              style={{ backgroundColor: item.color }}
            />
            <p className="text-xs text-gray-500">{item.name}</p>
            <p className="text-sm font-semibold">{item.value}</p>
            <p className="text-xs text-gray-400">
              {total > 0 ? ((item.value / total) * 100).toFixed(0) : 0}%
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LeadQualityChart;


// src/components/dashboard/ChannelComparison.tsx

import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { ChannelData } from '../../types/dashboard.types';

interface ChannelComparisonProps {
  data: ChannelData[];
}

const ChannelComparison: React.FC<ChannelComparisonProps> = ({ data }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Channel Comparison</h3>
      
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
            <XAxis dataKey="channel" tick={{ fontSize: 12 }} />
            <YAxis tick={{ fontSize: 12 }} />
            <Tooltip
              contentStyle={{
                backgroundColor: 'white',
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
              }}
            />
            <Legend />
            <Bar
              dataKey="conversations"
              fill="#3B82F6"
              name="Conversations"
              radius={[4, 4, 0, 0]}
            />
            <Bar
              dataKey="bookingRate"
              fill="#10B981"
              name="Booking Rate %"
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b">
              <th className="text-left py-2 text-gray-500 font-medium">Channel</th>
              <th className="text-right py-2 text-gray-500 font-medium">Calls</th>
              <th className="text-right py-2 text-gray-500 font-medium">Booking %</th>
              <th className="text-right py-2 text-gray-500 font-medium">Avg Duration</th>
              <th className="text-right py-2 text-gray-500 font-medium">Sentiment</th>
            </tr>
          </thead>
          <tbody>
            {data.map((channel) => (
              <tr key={channel.channel} className="border-b last:border-0">
                <td className="py-2 font-medium">{channel.channel}</td>
                <td className="py-2 text-right">{channel.conversations}</td>
                <td className="py-2 text-right text-green-600">{channel.bookingRate}%</td>
                <td className="py-2 text-right">
                  {Math.floor(channel.avgDuration / 60)}:{(channel.avgDuration % 60).toString().padStart(2, '0')}
                </td>
                <td className="py-2 text-right">
                  <span className={channel.avgSentiment >= 70 ? 'text-green-600' : channel.avgSentiment >= 40 ? 'text-yellow-600' : 'text-red-600'}>
                    {channel.avgSentiment}%
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ChannelComparison;
