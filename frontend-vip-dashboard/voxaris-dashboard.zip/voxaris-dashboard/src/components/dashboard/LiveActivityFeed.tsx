// src/components/dashboard/LiveActivityFeed.tsx

import React from 'react';
import { formatDistanceToNow } from 'date-fns';
import {
  MessageSquare,
  Phone,
  Video,
  Calendar,
  CheckCircle,
  XCircle,
  User,
  DollarSign,
} from 'lucide-react';
import { Activity } from '../../types/dashboard.types';

interface LiveActivityFeedProps {
  events: Activity[];
  maxHeight?: string;
}

const LiveActivityFeed: React.FC<LiveActivityFeedProps> = ({
  events,
  maxHeight = '400px',
}) => {
  const getActivityIcon = (type: Activity['type'], channel: Activity['channel']) => {
    const iconClass = 'w-4 h-4';

    switch (type) {
      case 'qr_scan':
        return <User className={`${iconClass} text-blue-500`} />;
      case 'conversation_started':
      case 'conversation_ended':
        if (channel === 'tavus')
          return <Video className={`${iconClass} text-purple-500`} />;
        if (channel === 'retell' || channel === 'ghl_voice')
          return <Phone className={`${iconClass} text-green-500`} />;
        return <MessageSquare className={`${iconClass} text-blue-500`} />;
      case 'appointment_booked':
        return <Calendar className={`${iconClass} text-indigo-500`} />;
      case 'appointment_showed':
        return <CheckCircle className={`${iconClass} text-green-500`} />;
      case 'appointment_no_show':
        return <XCircle className={`${iconClass} text-red-500`} />;
      case 'deal_closed':
        return <DollarSign className={`${iconClass} text-green-500`} />;
      case 'deal_lost':
        return <XCircle className={`${iconClass} text-gray-500`} />;
      default:
        return <MessageSquare className={`${iconClass} text-gray-500`} />;
    }
  };

  const getActivityText = (activity: Activity) => {
    switch (activity.type) {
      case 'qr_scan':
        return 'scanned QR code';
      case 'conversation_started':
        return `started ${activity.channel === 'tavus' ? 'video' : 'voice'} call`;
      case 'conversation_ended':
        return `completed ${activity.channel === 'tavus' ? 'video' : 'voice'} call`;
      case 'appointment_booked':
        return `booked appointment${
          activity.metadata?.appointmentTime
            ? ` for ${activity.metadata.appointmentTime}`
            : ''
        }`;
      case 'appointment_showed':
        return 'showed up for appointment';
      case 'appointment_no_show':
        return 'missed appointment';
      case 'deal_closed':
        return `closed deal${
          activity.metadata?.dealValue
            ? ` - $${activity.metadata.dealValue.toLocaleString()}`
            : ''
        }`;
      case 'deal_lost':
        return 'deal lost';
      default:
        return activity.type.replace(/_/g, ' ');
    }
  };

  const getChannelBadge = (channel: Activity['channel']) => {
    const badges: Record<string, { label: string; color: string }> = {
      tavus: { label: 'Video', color: 'bg-purple-100 text-purple-700' },
      retell: { label: 'Retell', color: 'bg-green-100 text-green-700' },
      ghl_voice: { label: 'Voice AI', color: 'bg-blue-100 text-blue-700' },
      ghl_chat: { label: 'Chat', color: 'bg-gray-100 text-gray-700' },
      manual: { label: 'Manual', color: 'bg-gray-100 text-gray-700' },
    };

    const badge = badges[channel] || badges.manual;

    return (
      <span className={`text-xs px-2 py-0.5 rounded-full ${badge.color}`}>
        {badge.label}
      </span>
    );
  };

  const getActivityBgColor = (type: Activity['type']) => {
    switch (type) {
      case 'deal_closed':
        return 'bg-green-50';
      case 'appointment_booked':
        return 'bg-indigo-50';
      case 'appointment_no_show':
      case 'deal_lost':
        return 'bg-red-50';
      default:
        return '';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border">
      <div className="p-4 border-b flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">Live Activity</h3>
        <span className="flex items-center gap-2 text-sm text-green-600">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          Live
        </span>
      </div>

      <div
        className="overflow-y-auto"
        style={{ maxHeight }}
      >
        {events.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            <MessageSquare className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <p>No activity yet</p>
            <p className="text-sm">Waiting for events...</p>
          </div>
        ) : (
          <div className="divide-y">
            {events.map((activity) => (
              <div
                key={activity.id}
                className={`p-4 hover:bg-gray-50 transition-colors ${getActivityBgColor(
                  activity.type
                )}`}
              >
                <div className="flex items-start gap-3">
                  <div className="mt-1">
                    {getActivityIcon(activity.type, activity.channel)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium text-gray-900 truncate">
                        {activity.contactName}
                      </span>
                      {getChannelBadge(activity.channel)}
                    </div>
                    <p className="text-sm text-gray-600 mt-0.5">
                      {getActivityText(activity)}
                    </p>
                    {activity.vehicle && (
                      <p className="text-xs text-gray-400 mt-0.5">
                        {activity.vehicle}
                      </p>
                    )}
                  </div>
                  <div className="text-xs text-gray-400 whitespace-nowrap">
                    {formatDistanceToNow(activity.timestamp, { addSuffix: true })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default LiveActivityFeed;


// src/components/dashboard/ConversionFunnel.tsx

import React from 'react';
import {
  FunnelChart,
  Funnel,
  Tooltip,
  ResponsiveContainer,
  Cell,
  LabelList,
} from 'recharts';
import { FunnelStage } from '../../types/dashboard.types';

interface ConversionFunnelProps {
  data: FunnelStage[];
}

const ConversionFunnel: React.FC<ConversionFunnelProps> = ({ data }) => {
  const COLORS = [
    '#3B82F6', // blue
    '#6366F1', // indigo
    '#8B5CF6', // purple
    '#A855F7', // violet
    '#EC4899', // pink
    '#22C55E', // green
  ];

  const funnelData = [
    { name: 'Mailers Sent', value: data[0]?.count || 0, fill: COLORS[0] },
    { name: 'QR Scanned', value: data[1]?.count || 0, fill: COLORS[1] },
    { name: 'AI Conversation', value: data[2]?.count || 0, fill: COLORS[2] },
    { name: 'Appt Booked', value: data[3]?.count || 0, fill: COLORS[3] },
    { name: 'Showed Up', value: data[4]?.count || 0, fill: COLORS[4] },
    { name: 'Deal Closed', value: data[5]?.count || 0, fill: COLORS[5] },
  ];

  const getConversionRateColor = (rate: number) => {
    if (rate >= 50) return 'text-green-600';
    if (rate >= 25) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">
        Conversion Funnel
      </h3>

      <div className="h-72">
        <ResponsiveContainer width="100%" height="100%">
          <FunnelChart>
            <Tooltip
              formatter={(value: number, name: string) => [
                `${value.toLocaleString()} contacts`,
                name,
              ]}
              contentStyle={{
                backgroundColor: 'white',
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
              }}
            />
            <Funnel dataKey="value" data={funnelData} isAnimationActive>
              <LabelList
                position="right"
                fill="#374151"
                stroke="none"
                dataKey="name"
                fontSize={12}
              />
              <LabelList
                position="center"
                fill="#fff"
                stroke="none"
                dataKey="value"
                formatter={(value: number) => value.toLocaleString()}
                fontSize={14}
                fontWeight="bold"
              />
              {funnelData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.fill} />
              ))}
            </Funnel>
          </FunnelChart>
        </ResponsiveContainer>
      </div>

      {/* Conversion Rates */}
      <div className="mt-4 grid grid-cols-5 gap-2">
        {data.slice(1).map((stage, index) => (
          <div
            key={stage.stage}
            className="text-center p-2 bg-gray-50 rounded-lg"
          >
            <div className="text-xs text-gray-500 truncate" title={`${data[index]?.stage} → ${stage.stage}`}>
              Stage {index + 1} → {index + 2}
            </div>
            <div
              className={`text-lg font-semibold ${getConversionRateColor(
                stage.conversionRate
              )}`}
            >
              {stage.conversionRate.toFixed(0)}%
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ConversionFunnel;
