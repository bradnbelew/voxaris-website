// src/components/dashboard/AppointmentCalendar.tsx

import React, { useState } from 'react';
import { format, isToday, isTomorrow, isPast } from 'date-fns';
import {
  Calendar,
  User,
  Phone,
  Mail,
  Car,
  CheckCircle,
  XCircle,
} from 'lucide-react';
import { Appointment } from '../../types/dashboard.types';
import { dashboardApi } from '../../api/dashboardApi';

interface AppointmentCalendarProps {
  appointments: Appointment[];
  onStatusChange: () => void;
}

const AppointmentCalendar: React.FC<AppointmentCalendarProps> = ({
  appointments,
  onStatusChange,
}) => {
  const [filter, setFilter] = useState<'all' | 'upcoming' | 'today' | 'completed'>('upcoming');
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const getStatusBadge = (status: Appointment['status']) => {
    const styles: Record<Appointment['status'], string> = {
      scheduled: 'bg-blue-100 text-blue-700',
      confirmed: 'bg-green-100 text-green-700',
      completed: 'bg-gray-100 text-gray-700',
      no_show: 'bg-red-100 text-red-700',
      cancelled: 'bg-gray-100 text-gray-500',
      rescheduled: 'bg-yellow-100 text-yellow-700',
    };

    const label = status.replace('_', ' ');

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status]}`}>
        {label.charAt(0).toUpperCase() + label.slice(1)}
      </span>
    );
  };

  const getSourceBadge = (source: Appointment['source']) => {
    const styles: Record<Appointment['source'], { label: string; color: string }> = {
      tavus: { label: 'Video', color: 'bg-purple-100 text-purple-700' },
      retell: { label: 'Retell', color: 'bg-green-100 text-green-700' },
      ghl_voice: { label: 'Voice AI', color: 'bg-blue-100 text-blue-700' },
      ghl_chat: { label: 'Chat', color: 'bg-gray-100 text-gray-700' },
      manual: { label: 'Manual', color: 'bg-gray-100 text-gray-700' },
    };

    const badge = styles[source] || styles.manual;

    return (
      <span className={`px-2 py-0.5 rounded text-xs ${badge.color}`}>
        {badge.label}
      </span>
    );
  };

  const getDateLabel = (date: Date) => {
    if (isToday(date)) return 'Today';
    if (isTomorrow(date)) return 'Tomorrow';
    return format(date, 'EEE, MMM d');
  };

  const filteredAppointments = appointments.filter((apt) => {
    const aptDate = new Date(apt.appointmentDate);
    
    switch (filter) {
      case 'today':
        return isToday(aptDate);
      case 'upcoming':
        return !isPast(aptDate) || isToday(aptDate);
      case 'completed':
        return apt.status === 'completed' || apt.status === 'no_show';
      default:
        return true;
    }
  });

  const sortedAppointments = [...filteredAppointments].sort((a, b) => 
    new Date(a.appointmentDate).getTime() - new Date(b.appointmentDate).getTime()
  );

  const handleStatusUpdate = async (appointmentId: string, newStatus: Appointment['status']) => {
    setUpdatingId(appointmentId);
    try {
      await dashboardApi.updateAppointmentStatus(appointmentId, newStatus);
      onStatusChange();
    } catch (error) {
      console.error('Failed to update appointment status:', error);
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header with filters */}
      <div className="bg-white rounded-xl shadow-sm border p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-gray-600" />
            <h3 className="text-lg font-semibold text-gray-900">Appointments</h3>
            <span className="bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full text-sm">
              {filteredAppointments.length}
            </span>
          </div>

          <div className="flex gap-2">
            {(['all', 'upcoming', 'today', 'completed'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                  filter === f
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-500 hover:bg-gray-100'
                }`}
              >
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Appointments List */}
      <div className="space-y-4">
        {sortedAppointments.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm border p-8 text-center">
            <Calendar className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <p className="text-gray-500">No appointments found</p>
            <p className="text-sm text-gray-400">
              {filter === 'today'
                ? 'No appointments scheduled for today'
                : filter === 'upcoming'
                ? 'No upcoming appointments'
                : 'No appointments match your filter'}
            </p>
          </div>
        ) : (
          sortedAppointments.map((appointment) => (
            <div
              key={appointment.id}
              className={`bg-white rounded-xl shadow-sm border p-6 hover:shadow-md transition-shadow ${
                isPast(new Date(appointment.appointmentDate)) && appointment.status === 'scheduled'
                  ? 'border-yellow-300 bg-yellow-50'
                  : ''
              }`}
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                {/* Left: Date & Time */}
                <div className="flex items-start gap-4">
                  <div className="text-center min-w-[80px]">
                    <p className="text-sm font-medium text-gray-500">
                      {getDateLabel(new Date(appointment.appointmentDate))}
                    </p>
                    <p className="text-2xl font-bold text-gray-900">
                      {appointment.appointmentTime}
                    </p>
                  </div>

                  <div className="border-l pl-4">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <User className="w-4 h-4 text-gray-400" />
                      <span className="font-semibold text-gray-900">
                        {appointment.contactName}
                      </span>
                      {getStatusBadge(appointment.status)}
                      {getSourceBadge(appointment.source)}
                    </div>

                    <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <Phone className="w-3 h-3" />
                        {appointment.contactPhone}
                      </span>
                      {appointment.contactEmail && (
                        <span className="flex items-center gap-1">
                          <Mail className="w-3 h-3" />
                          {appointment.contactEmail}
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        <Car className="w-3 h-3" />
                        {appointment.vehicle}
                      </span>
                    </div>

                    {appointment.notes && (
                      <p className="mt-2 text-sm text-gray-600 italic">
                        "{appointment.notes}"
                      </p>
                    )}
                  </div>
                </div>

                {/* Right: Actions */}
                <div className="flex items-center gap-2 lg:ml-auto flex-wrap">
                  {appointment.status === 'scheduled' && (
                    <>
                      <button
                        onClick={() => handleStatusUpdate(appointment.id, 'confirmed')}
                        disabled={updatingId === appointment.id}
                        className="flex items-center gap-1 px-3 py-1.5 bg-green-100 text-green-700 rounded-lg text-sm hover:bg-green-200 transition-colors disabled:opacity-50"
                      >
                        <CheckCircle className="w-4 h-4" />
                        Confirm
                      </button>
                      <button
                        onClick={() => handleStatusUpdate(appointment.id, 'cancelled')}
                        disabled={updatingId === appointment.id}
                        className="flex items-center gap-1 px-3 py-1.5 bg-red-100 text-red-700 rounded-lg text-sm hover:bg-red-200 transition-colors disabled:opacity-50"
                      >
                        <XCircle className="w-4 h-4" />
                        Cancel
                      </button>
                    </>
                  )}

                  {appointment.status === 'confirmed' && (
                    <>
                      <button
                        onClick={() => handleStatusUpdate(appointment.id, 'completed')}
                        disabled={updatingId === appointment.id}
                        className="flex items-center gap-1 px-3 py-1.5 bg-green-100 text-green-700 rounded-lg text-sm hover:bg-green-200 transition-colors disabled:opacity-50"
                      >
                        <CheckCircle className="w-4 h-4" />
                        Showed
                      </button>
                      <button
                        onClick={() => handleStatusUpdate(appointment.id, 'no_show')}
                        disabled={updatingId === appointment.id}
                        className="flex items-center gap-1 px-3 py-1.5 bg-red-100 text-red-700 rounded-lg text-sm hover:bg-red-200 transition-colors disabled:opacity-50"
                      >
                        <XCircle className="w-4 h-4" />
                        No Show
                      </button>
                    </>
                  )}

                  {(appointment.status === 'completed' || appointment.status === 'no_show') && (
                    <span className="text-sm text-gray-400">
                      {appointment.status === 'completed' ? '✓ Completed' : '✗ No Show'}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AppointmentCalendar;
