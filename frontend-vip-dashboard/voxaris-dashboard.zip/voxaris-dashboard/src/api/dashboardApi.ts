// src/api/dashboardApi.ts

import { 
  DashboardData, 
  DashboardFilters, 
  CampaignMetrics, 
  FunnelStage, 
  AIMetrics, 
  Appointment, 
  ROIData, 
  Activity 
} from '../types/dashboard.types';

const API_BASE = import.meta.env.VITE_API_URL || 'https://api.voxaris.io/v1';

async function fetchWithAuth(url: string, options: RequestInit = {}) {
  const token = localStorage.getItem('voxaris_token') || 
                new URLSearchParams(window.location.search).get('token');
  
  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token && { 'Authorization': `Bearer ${token}` }),
      ...options.headers,
    },
  });

  if (!response.ok) {
    throw new Error(`API error: ${response.status} ${response.statusText}`);
  }

  return response.json();
}

export const dashboardApi = {
  // Get full dashboard data
  getDashboard: async (filters: DashboardFilters): Promise<DashboardData> => {
    const params = new URLSearchParams({
      locationId: filters.locationId,
      startDate: filters.startDate.toISOString(),
      endDate: filters.endDate.toISOString(),
      ...(filters.campaignId && { campaignId: filters.campaignId }),
    });
    
    return fetchWithAuth(`${API_BASE}/dashboard?${params}`);
  },

  // Get campaign metrics only
  getMetrics: async (filters: DashboardFilters): Promise<CampaignMetrics> => {
    const params = new URLSearchParams({
      locationId: filters.locationId,
      startDate: filters.startDate.toISOString(),
      endDate: filters.endDate.toISOString(),
      ...(filters.campaignId && { campaignId: filters.campaignId }),
    });
    
    return fetchWithAuth(`${API_BASE}/dashboard/metrics?${params}`);
  },

  // Get funnel data
  getFunnel: async (filters: DashboardFilters): Promise<FunnelStage[]> => {
    const params = new URLSearchParams({
      locationId: filters.locationId,
      startDate: filters.startDate.toISOString(),
      endDate: filters.endDate.toISOString(),
      ...(filters.campaignId && { campaignId: filters.campaignId }),
    });
    
    return fetchWithAuth(`${API_BASE}/dashboard/funnel?${params}`);
  },

  // Get AI performance metrics
  getAIMetrics: async (filters: DashboardFilters): Promise<AIMetrics> => {
    const params = new URLSearchParams({
      locationId: filters.locationId,
      startDate: filters.startDate.toISOString(),
      endDate: filters.endDate.toISOString(),
      ...(filters.campaignId && { campaignId: filters.campaignId }),
    });
    
    return fetchWithAuth(`${API_BASE}/dashboard/ai-metrics?${params}`);
  },

  // Get appointments
  getAppointments: async (filters: DashboardFilters): Promise<Appointment[]> => {
    const params = new URLSearchParams({
      locationId: filters.locationId,
      startDate: filters.startDate.toISOString(),
      endDate: filters.endDate.toISOString(),
      ...(filters.campaignId && { campaignId: filters.campaignId }),
    });
    
    return fetchWithAuth(`${API_BASE}/dashboard/appointments?${params}`);
  },

  // Get ROI data
  getROI: async (filters: DashboardFilters): Promise<ROIData> => {
    const params = new URLSearchParams({
      locationId: filters.locationId,
      startDate: filters.startDate.toISOString(),
      endDate: filters.endDate.toISOString(),
      ...(filters.campaignId && { campaignId: filters.campaignId }),
    });
    
    return fetchWithAuth(`${API_BASE}/dashboard/roi?${params}`);
  },

  // Get live activity events
  getRecentActivity: async (locationId: string, limit = 50): Promise<Activity[]> => {
    const params = new URLSearchParams({
      locationId,
      limit: limit.toString(),
    });
    
    return fetchWithAuth(`${API_BASE}/dashboard/activity?${params}`);
  },

  // Export report as PDF or CSV
  exportReport: async (
    filters: DashboardFilters, 
    format: 'pdf' | 'csv'
  ): Promise<Blob> => {
    const params = new URLSearchParams({
      locationId: filters.locationId,
      startDate: filters.startDate.toISOString(),
      endDate: filters.endDate.toISOString(),
      format,
      ...(filters.campaignId && { campaignId: filters.campaignId }),
    });
    
    const response = await fetch(`${API_BASE}/dashboard/export?${params}`, {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('voxaris_token')}`,
      },
    });
    
    return response.blob();
  },

  // Update appointment status
  updateAppointmentStatus: async (
    appointmentId: string, 
    status: Appointment['status']
  ): Promise<Appointment> => {
    return fetchWithAuth(`${API_BASE}/appointments/${appointmentId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
  },

  // Record deal outcome
  recordDealOutcome: async (
    contactId: string,
    outcome: {
      dealClosed: boolean;
      dealType?: string;
      appraisalValue?: number;
      dealValue?: number;
      notes?: string;
    }
  ): Promise<void> => {
    return fetchWithAuth(`${API_BASE}/deals`, {
      method: 'POST',
      body: JSON.stringify({ contactId, ...outcome }),
    });
  },
};

export default dashboardApi;
